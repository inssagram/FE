---
name: "🐞Bug"
about: Bug 버그를 알려주세요
title: ""
labels: ""
assignees: ""
---

## Description

버그 내용을 설명해주세요

## To-Do

- [ ] todo
- [x] todo

## ETC
