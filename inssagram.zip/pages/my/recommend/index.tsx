
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as SC from "@/components/styled/my_recommend";
import Image from "next/image";
import { faEllipsis, faChevronLeft } from "@fortawesome/free-solid-svg-icons";
import Footer from "@/components/Footer";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import axios from "axios";
import Link from "next/link";

export interface Post {
  id: number;
  userId: string;
  introduce: string;
}

const Recommend: React.FC = () => {
  const router = useRouter();
  const { id } = router.query;
  const [recommendPosts, setRecommendPosts] = useState<Post[]>([]);
  const [following, setFollowing] = useState<boolean[]>([]);

  useEffect(() => {
    const fetchData = async() => {
      try{
        console.log("Fetching data...");

const response = await axios.get("http://localhost:4000/recommend");

console.log("Data fetched:", response.data);
        console.log(response.data);
        setRecommendPosts(response.data);

        setFollowing(response.data.map(()=> false)); //팔로우 배열 초기화하기
      } catch(error) {
        console.error("데이터를 불러오는 데 실패했습니다", error);
      }  
    }
    fetchData();
  }, []);

  const handleFollow = (index:number) => {
    const updatedFollowing = [...following];
    updatedFollowing[index] = !updatedFollowing[index];
    setFollowing(updatedFollowing);
  }

  const handlePrevClick = () => {
    router.push("/my");
  };

  return (
    <SC.Container>
      <SC.Header>
        <SC.Prev onClick={handlePrevClick}>
          <FontAwesomeIcon icon={faChevronLeft} />
        </SC.Prev>
        <SC.H1>팔로우할 만한 계정 둘러보기</SC.H1>
      </SC.Header>
      <SC.RecommendCont>
        <SC.Recommend>추천</SC.Recommend>

        {/* <SC.UserCont>
          <SC.UserProfile />
          <SC.UserStatus>
            <SC.UserId>h</SC.UserId>
            <SC.UserIntro>hhh</SC.UserIntro>
            <SC.UserFollower>회원님을 팔로우합니다</SC.UserFollower>
          </SC.UserStatus>
          <SC.FollowButton>팔로우</SC.FollowButton>
          </SC.UserCont> */}
        
        {recommendPosts.map((post, index) => (
  <Link href={`/user/${post.userId}`} key={index}>
    <SC.UserCont>
      <SC.UserProfile />
      <SC.UserStatus>
        <SC.UserId>{post.userId}</SC.UserId>
        {post.introduce && <SC.UserIntro>{post?.introduce}</SC.UserIntro>}
        <SC.UserFollower>회원님을 팔로우합니다</SC.UserFollower>
      </SC.UserStatus>
      <SC.FollowButton
        onClick={() => handleFollow(index)}
        className={following[index] ? "following" : ""}
      >
        {following[index] ? "팔로잉" : "팔로우"}
      </SC.FollowButton>
    </SC.UserCont>
  </Link>
))}

      </SC.RecommendCont>
    </SC.Container>
  );
};

export default Recommend;